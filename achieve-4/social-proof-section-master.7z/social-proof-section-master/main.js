let ask= prompt('hello 🙂','');
switch(ask){
 case 'hi':
  case 'Hi':
   case 'yeah':
    case 'bonjour':
     case 'konichiha':
      case 'yes':
       case 'hello':
        case 'ok':
         case 'Ok':
        case 'Hello':
         case 'hey mate':
          alert('please in case you notice any issues\n based on responsiveness, kindly indicate\n\t via Frontendmentor. Thanks 😊');
          break;
          case null:
        alert('hope you will correct my mistakes! 😊');
        break;
        default:
        alert('Have  a nice day');
        break;
}
// my js skills are relatively low
// still hanging with the core.
