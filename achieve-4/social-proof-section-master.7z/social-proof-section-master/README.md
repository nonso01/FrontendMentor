# Frontend Mentor - Social proof section

![Design preview for the Social proof section coding challenge](./design/desktop-preview.jpg)

## Welcome! 👋

Thanks for checking out this front-end coding challenge.
